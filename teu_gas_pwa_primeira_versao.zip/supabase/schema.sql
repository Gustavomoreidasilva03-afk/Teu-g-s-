create extension if not exists pgcrypto;
create table if not exists public.customer_profiles(id uuid primary key references auth.users(id) on delete cascade,full_name text not null,phone text not null,cpf text not null unique,created_at timestamptz default now());
create table if not exists public.products(id text primary key,name text not null,category text not null,size text not null,active boolean default true,stock integer not null default 0 check(stock>=0),low_stock_threshold integer not null default 3,price_config jsonb not null default '{}'::jsonb);
create table if not exists public.delivery_neighborhoods(name text primary key,fee numeric(10,2) not null default 0 check(fee>=0),active boolean default true);
create table if not exists public.orders(id uuid primary key default gen_random_uuid(),code text unique not null,customer_id uuid references auth.users(id),customer_name text not null,phone text not null,cpf text,address text,items jsonb not null,fulfillment text not null,neighborhood text references public.delivery_neighborhoods(name),delivery_fee numeric(10,2) not null default 0,payment_method text not null,total numeric(10,2) not null,status text not null default 'received',paid boolean not null default false,created_at timestamptz default now());
create table if not exists public.stock_movements(id uuid primary key default gen_random_uuid(),product_id text references public.products(id),quantity_change integer not null,reason text not null,order_id uuid references public.orders(id),created_by uuid references auth.users(id),created_at timestamptz default now());
create table if not exists public.admin_users(user_id uuid primary key references auth.users(id) on delete cascade);
create or replace function public.is_teugas_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.admin_users where user_id=auth.uid()); $$;
alter table public.customer_profiles enable row level security;alter table public.products enable row level security;alter table public.delivery_neighborhoods enable row level security;alter table public.orders enable row level security;alter table public.stock_movements enable row level security;alter table public.admin_users enable row level security;
create policy "active products readable" on public.products for select using(active or public.is_teugas_admin());
create policy "active neighborhoods readable" on public.delivery_neighborhoods for select using(active or public.is_teugas_admin());
create policy "profile own" on public.customer_profiles for select using(auth.uid()=id or public.is_teugas_admin());
create policy "orders own read" on public.orders for select using(customer_id=auth.uid() or public.is_teugas_admin());
create policy "orders own create" on public.orders for insert with check(customer_id=auth.uid());
create policy "admin orders" on public.orders for all using(public.is_teugas_admin()) with check(public.is_teugas_admin());
create policy "admin products" on public.products for all using(public.is_teugas_admin()) with check(public.is_teugas_admin());
create policy "admin neighborhoods" on public.delivery_neighborhoods for all using(public.is_teugas_admin()) with check(public.is_teugas_admin());
create policy "admin stock" on public.stock_movements for all using(public.is_teugas_admin()) with check(public.is_teugas_admin());
create policy "admin list" on public.admin_users for select using(public.is_teugas_admin());
-- Cadastre a conta admin em Authentication e insira o UUID dela em public.admin_users.
-- Não exponha a service_role key no navegador. Revise políticas antes de produção.
