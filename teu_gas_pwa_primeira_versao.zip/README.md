# TEU GÁS — primeira versão PWA

Projeto inicial com interface de catálogo, carrinho, taxas por bairro, fluxo de pedido e painel demonstrativo. O pacote ainda não está hospedado nem conectado ao banco real.

## Rodar
Requer Node.js 20+:
```bash
npm install
cp .env.example .env
npm run dev
```

## Supabase
1. Crie projeto no Supabase.
2. Execute `supabase/schema.sql` no SQL Editor.
3. Cadastre o usuário administrador em Authentication.
4. Insira o UUID dele em `admin_users`: `insert into public.admin_users(user_id) values ('UUID');`
5. Preencha `.env` com Project URL e chave anon/public.
6. Reinicie o Vite.

**Não coloque a chave service_role no frontend.** O modo sem Supabase é apenas demonstração local; pedidos não são sincronizados entre aparelhos.

## Regras comerciais carregadas
Gás Fogás 13 kg: retirada Pix R$117,73, dinheiro R$125, cartão R$130, entrega R$140.
Gás 10 kg: R$115 retirada / R$127 entrega.
Gás 8 kg: R$97 retirada / R$112 entrega.
Gás 5 kg: R$77 retirada / R$100 entrega.
Vasilhame gás vazio: R$150 além da recarga.
Purágua: troca R$10 retirada / R$13 entrega; galão novo com água R$41 total.
Friágua: troca R$12 retirada / R$14 entrega; galão novo com água R$43 total.
Pagamento presencial: Pix, dinheiro, débito e crédito.
Estoque baixo: 3 unidades ou menos.
Bairros e taxas cadastrados no arquivo `src/data.ts`.

## Antes de operar com clientes reais
Ainda falta concluir: autenticação de cliente com telefone/senha, cadastro de CPF com proteção LGPD, sincronização segura de pedidos, validação de preços/taxas no servidor, controle transacional de estoque, notificações push/som, edição de catálogo no painel, recuperação de senha, testes e hospedagem HTTPS. O protótipo atual salva pedidos no navegador local e não deve ser usado para coletar CPFs reais.
